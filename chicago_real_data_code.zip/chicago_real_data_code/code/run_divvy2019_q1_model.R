options(stringsAsFactors = FALSE)
suppressPackageStartupMessages(library(data.table))

# This handoff version resolves all input/output paths relative to itself.

script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
if (!length(script_arg)) {
  stop("Run this file with Rscript so its bundle path can be resolved.")
}
this_file <- normalizePath(
  sub("^--file=", "", script_arg[1L]),
  winslash = "/",
  mustWork = TRUE
)
bundle_dir <- normalizePath(file.path(dirname(this_file), ".."), winslash = "/")

panel_file <- file.path(bundle_dir, "data", "divvy2019_q1_model_data.csv")
coord_file <- file.path(
  bundle_dir,
  "data",
  "divvy2019_station_temperature_grid_mapping.csv"
)
results_name <- Sys.getenv("DIVVY_RESULTS_DIR", unset = "reproduced_results")
out_dir <- file.path(bundle_dir, results_name)
model_start_date <- as.IDate("2019-01-01")
model_end_date <- as.IDate("2019-03-31")
sample_label <- "2019_Q1"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

tau_c <- 0.50
k_c <- 0.60
alpha <- 0.05

d <- fread(panel_file)
d[, `:=`(
  station_id = as.character(station_id),
  date = as.IDate(date),
  y_raw = log1p(departures),
  x_raw = temp_it_c,
  z_raw = prcp_it_mm
)]
d <- d[date >= model_start_date & date <= model_end_date]
setorder(d, station_id, date)

ids <- sort(unique(d$station_id))
dates <- sort(unique(d$date))
n <- length(ids)
TT <- length(dates)
expected_T <- as.integer(model_end_date - model_start_date) + 1L
stopifnot(n == 344L, TT == expected_T, nrow(d) == n * TT)
stopifnot(all(d[, .N, by = station_id]$N == TT))
stopifnot(all(is.finite(d$y_raw)), all(is.finite(d$x_raw)), all(is.finite(d$z_raw)))

# One global z-score per variable, shared by every station.
scale_stats <- data.table(
  variable = c("log1p_departures", "daymet_mean_temperature_c", "daymet_prcp_mm"),
  mean = c(mean(d$y_raw), mean(d$x_raw), mean(d$z_raw)),
  sd = c(sd(d$y_raw), sd(d$x_raw), sd(d$z_raw))
)
d[, y_std := (y_raw - scale_stats$mean[1L]) / scale_stats$sd[1L]]
d[, x_std := (x_raw - scale_stats$mean[2L]) / scale_stats$sd[2L]]
d[, z_std := (z_raw - scale_stats$mean[3L]) / scale_stats$sd[3L]]

wide <- function(value) {
  w <- dcast(d, date ~ station_id, value.var = value)
  setorder(w, date)
  ans <- as.matrix(w[, ..ids])
  colnames(ans) <- ids
  ans
}

Y <- wide("y_std")
X <- wide("x_std")
Z <- wide("z_std")

# Within transformation removes station fixed effects.
Yw <- sweep(Y, 2L, colMeans(Y), "-")
Xw <- sweep(X, 2L, colMeans(X), "-")
Zw <- sweep(Z, 2L, colMeans(Z), "-")
xx <- colSums(Xw^2)
stopifnot(all(xx > 1e-10))

# Algorithm 1, Step 1: equations (2.2)-(2.3).
xz_over_xx <- colSums(Xw * Zw) / xx
xy_over_xx <- colSums(Xw * Yw) / xx
Z_Mx_Z <- colSums(Zw^2) - xx * xz_over_xx^2
Z_Mx_Y <- colSums(Zw * Yw) - xx * xz_over_xx * xy_over_xx
theta_hat <- sum(Z_Mx_Y) / sum(Z_Mx_Z)
beta_initial <- colSums(Xw * (Yw - theta_hat * Zw)) / xx

# Algorithm 1, Step 2: pairwise-distance neighborhood screening.
distances <- abs(outer(beta_initial, beta_initial, "-"))
pair_distances <- distances[upper.tri(distances)]
C0_hat <- as.numeric(quantile(pair_distances, tau_c, type = 7, names = FALSE))
neighbor_score <- (rowSums(distances <= C0_hat) - 1L) / (n - 1L)
clean_n <- floor(k_c * n)
clean_idx <- order(-neighbor_score, ids)[seq_len(clean_n)]
clean <- seq_len(n) %in% clean_idx

# Algorithm 1, Step 3: clean-set common slope and LM statistics.
beta_common <- sum(colSums(Xw[, clean, drop = FALSE] *
                           (Yw[, clean, drop = FALSE] - theta_hat * Zw[, clean, drop = FALSE]))) /
  sum(xx[clean])
xi_hat <- Yw - beta_common * Xw - theta_hat * Zw
LM <- colSums(Xw * xi_hat)^2 / xx
sigma2_hat <- sum(xi_hat[, clean, drop = FALSE]^2) / (clean_n * (TT - 1L))
S <- LM / sigma2_hat
p_value <- pchisq(S, df = 1L, lower.tail = FALSE)

# Algorithm 1, Step 4: equation (2.7), FDR alpha=0.05.
p_ord <- order(p_value, ids)
p_sorted <- p_value[p_ord]
eligible <- which(n * p_sorted / seq_len(n) <= alpha)
j_star <- if (length(eligible)) max(eligible) else 0L
# Equation (2.7) is a supremum over the continuous threshold u.  When
# j_star = max{j: p_(j) <= alpha*j/n}, its exact value is alpha*j_star/n;
# it is not the boundary p-value p_(j_star).
u_hat <- if (j_star > 0L) alpha * j_star / n else 0
rejected <- p_value <= u_hat & u_hat > 0

# Convert standardized coefficients back to log-demand per 1 C warmer.
beta_conversion <- scale_stats$sd[1L] / scale_stats$sd[2L]
theta_conversion <- scale_stats$sd[1L] / scale_stats$sd[3L]
beta_initial_raw <- beta_initial * beta_conversion
beta_common_raw <- beta_common * beta_conversion

coords <- fread(coord_file)
coords[, station_id := as.character(station_id)]
meta <- d[, .(
  station_name = station_name[1L],
  q1_total_departures = sum(departures),
  mean_daily_departures = mean(departures),
  mean_temperature_c = mean(temp_it_c),
  mean_precipitation_mm = mean(prcp_it_mm)
), by = station_id]

results <- data.table(
  station_id = ids,
  beta_initial_std = beta_initial,
  beta_initial_log_per_1C_warmer = beta_initial_raw,
  beta_common_std = beta_common,
  beta_common_log_per_1C_warmer = beta_common_raw,
  deviation_std = beta_initial - beta_common,
  neighbor_score = neighbor_score,
  preliminary_clean = clean,
  LM = LM,
  S_chisq1 = S,
  p_value = p_value,
  fdr_threshold = u_hat,
  rejected_fdr_5pct = rejected,
  anomaly_direction = fifelse(
    !rejected, "not_rejected",
    fifelse(beta_initial > beta_common, "more_warming_responsive", "less_warming_responsive")
  ),
  effect_percent_per_1C_warmer = 100 * (exp(beta_initial_raw) - 1),
  common_effect_percent_per_1C_warmer = 100 * (exp(beta_common_raw) - 1)
)
results <- merge(results, meta, by = "station_id", all.x = TRUE)
results <- merge(results, coords[, .(
  station_id, station_lat, station_lon, distance_to_grid_center_km
)], by = "station_id", all.x = TRUE)
setorder(results, p_value, station_id)

summary <- data.table(
  model = paste0("paper_algorithm_1_direct_temperature_", sample_label),
  sample_start = as.character(model_start_date),
  sample_end = as.character(model_end_date),
  outcome = "zscore(log1p(departures))",
  heterogeneous_regressor = "zscore(temp_it_c)",
  common_control = "zscore(daymet_prcp_it_mm)",
  N = n, T = TT, NT = n * TT,
  tau_c = tau_c,
  distance_threshold_C0 = C0_hat,
  retention_k_c = k_c,
  clean_N = clean_n,
  target_FDR_alpha = alpha,
  estimated_fdr_threshold = u_hat,
  theta_precip_std = theta_hat,
  theta_log_per_mm = theta_hat * theta_conversion,
  common_beta_std = beta_common,
  common_beta_log_per_1C_warmer = beta_common_raw,
  common_effect_percent_per_1C_warmer = 100 * (exp(beta_common_raw) - 1),
  sigma2_clean = sigma2_hat,
  anomalies = sum(rejected),
  more_warming_responsive = sum(rejected & beta_initial > beta_common),
  less_warming_responsive = sum(rejected & beta_initial < beta_common)
)

png(file.path(out_dir, "direct_temperature_slope_distribution.png"),
    width = 1800, height = 1200, res = 180)
par(mar = c(5, 5, 3, 1))
hist(results$beta_initial_log_per_1C_warmer, breaks = 35,
     col = "#D7EAF4", border = "white",
     xlab = "Initial station slope: log demand per 1 C warmer",
     main = paste(sample_label, "Divvy station direct-temperature slopes"))
abline(v = beta_common_raw, col = "#202A44", lwd = 3)
rug(results[rejected_fdr_5pct == TRUE, beta_initial_log_per_1C_warmer],
    col = "#C43C39", lwd = 2)
legend("topright", c("Clean-set common slope", "FDR-detected stations"),
       col = c("#202A44", "#C43C39"), lwd = c(3, 2), bty = "n")
dev.off()

png(file.path(out_dir, "direct_temperature_anomaly_map.png"),
    width = 1500, height = 1500, res = 180)
par(mar = c(5, 5, 3, 1))
map_cols <- fifelse(results$anomaly_direction == "more_warming_responsive", "#C43C39",
                    fifelse(results$anomaly_direction == "less_warming_responsive", "#2878B5", "#BCC4CC"))
map_cex <- fifelse(results$rejected_fdr_5pct, 1.15, 0.55)
plot(results$station_lon, results$station_lat, pch = 19, col = map_cols, cex = map_cex,
     xlab = "Longitude", ylab = "Latitude",
     main = paste(sample_label, "FDR-detected direct-temperature slope anomalies"))
legend("bottomleft", c("More warming-responsive", "Less warming-responsive", "Not rejected"),
       col = c("#C43C39", "#2878B5", "#BCC4CC"), pch = 19, bty = "n")
dev.off()

fwrite(scale_stats, file.path(out_dir, "standardization_parameters.csv"))
fwrite(summary, file.path(out_dir, "model_summary.csv"))
fwrite(results, file.path(out_dir, "station_results.csv"))
fwrite(results[rejected_fdr_5pct == TRUE], file.path(out_dir, "detected_anomalies.csv"))

cat("Completed direct-temperature baseline model.\n")
print(summary)
