options(stringsAsFactors = FALSE)

# Divvy 2019-Q1 anomaly map using official 2019 Census TIGER/Line vectors.
# No third-party rendered basemap tiles are used.

suppressPackageStartupMessages({
  library(sf)
  library(ggplot2)
})

resolve_bundle_dir <- function() {
  script_arg <- grep("^--file=", commandArgs(trailingOnly = FALSE), value = TRUE)
  candidates <- character()
  if (length(script_arg)) {
    script_file <- sub("^--file=", "", script_arg[1L])
    candidates <- c(candidates, file.path(dirname(script_file), ".."))
  }
  candidates <- unique(c(candidates, getwd(), file.path(getwd(), "..")))
  for (candidate in candidates) {
    if (file.exists(file.path(candidate, "results", "station_results.csv"))) {
      return(normalizePath(candidate, winslash = "/", mustWork = TRUE))
    }
  }
  stop("Could not locate the chicago_real_data_code directory.")
}

bundle <- resolve_bundle_dir()
stations_file <- file.path(bundle, "results", "station_results.csv")
tiger_dir <- file.path(bundle, "data", "tiger2019")
roads_file <- file.path(tiger_dir, "tl_2019_17031_roads", "tl_2019_17031_roads.shp")
water_file <- file.path(tiger_dir, "tl_2019_17031_areawater", "tl_2019_17031_areawater.shp")
linear_water_file <- file.path(tiger_dir, "tl_2019_17031_linearwater", "tl_2019_17031_linearwater.shp")

required <- c(stations_file, roads_file, water_file, linear_water_file)
if (any(!file.exists(required))) {
  stop("Missing input file(s):\n", paste(required[!file.exists(required)], collapse = "\n"))
}

# Same analysis window used in the existing Divvy map.
west <- -87.720
east <- -87.545
south <- 41.760
north <- 42.065
crop_box <- st_bbox(c(xmin = west, ymin = south, xmax = east, ymax = north), crs = 4326)

roads <- st_read(roads_file, quiet = TRUE)
water <- st_read(water_file, quiet = TRUE)
linear_water <- st_read(linear_water_file, quiet = TRUE)
tiger_crop_box <- st_bbox(st_transform(st_as_sfc(crop_box), st_crs(roads)))
roads <- suppressWarnings(st_crop(roads, tiger_crop_box))
water <- suppressWarnings(st_crop(water, tiger_crop_box))
linear_water <- suppressWarnings(st_crop(linear_water, tiger_crop_box))
roads <- suppressWarnings(st_collection_extract(roads, "LINESTRING"))
water <- suppressWarnings(st_collection_extract(water, "POLYGON"))
linear_water <- suppressWarnings(st_collection_extract(linear_water, "LINESTRING"))

# TIGER/Line feature classes: primary/secondary roads and local streets.
major_roads <- roads[roads$MTFCC %in% c("S1100", "S1200"), ]
local_roads <- roads[roads$MTFCC %in% c("S1400", "S1500", "S1630", "S1640"), ]

stations <- read.csv(stations_file, check.names = FALSE)
stopifnot(nrow(stations) == 344L)
stations$map_group <- ifelse(
  stations$anomaly_direction == "more_warming_responsive", "Above Benchmark",
  ifelse(stations$anomaly_direction == "less_warming_responsive",
         "Below Benchmark", "Not rejected")
)
stations$map_group <- factor(
  stations$map_group,
  levels = c("Above Benchmark", "Below Benchmark", "Not rejected")
)
# Draw ordinary stations first and anomalies last.
stations <- stations[order(stations$map_group != "Not rejected"), ]

references <- data.frame(
  station_lon = c(-87.6298, -87.5997),
  station_lat = c(41.8819, 41.7897),
  map_group = factor(
    c("Downtown Chicago (The Loop)", "University of Chicago"),
    levels = c("Above Benchmark", "Below Benchmark", "Not rejected",
               "Downtown Chicago (The Loop)", "University of Chicago")
  )
)

point_data <- rbind(
  stations[, c("station_lon", "station_lat", "map_group")],
  references[, c("station_lon", "station_lat", "map_group")]
)
point_data$map_group <- factor(
  as.character(point_data$map_group),
  levels = c("Above Benchmark", "Below Benchmark", "Not rejected",
             "Downtown Chicago (The Loop)", "University of Chicago")
)

fill_values <- c(
  "Above Benchmark" = "#E74C3C",
  "Below Benchmark" = "#2E86DE",
  "Not rejected" = "#777777",
  "Downtown Chicago (The Loop)" = "#F39C12",
  "University of Chicago" = "#7D3C98"
)
outline_values <- c(
  "Above Benchmark" = "#9E2B20",
  "Below Benchmark" = "#145A91",
  "Not rejected" = "#FFFFFF",
  "Downtown Chicago (The Loop)" = "#FFFFFF",
  "University of Chicago" = "#FFFFFF"
)
shape_values <- c(
  "Above Benchmark" = 21,
  "Below Benchmark" = 21,
  "Not rejected" = 21,
  "Downtown Chicago (The Loop)" = 23,
  "University of Chicago" = 24
)

# Convert the official sf geometry to ordinary longitude/latitude paths so the
# display can use the same square aspect ratio as the existing manuscript map.
# This changes only the visual aspect ratio, not feature locations or matching.
line_coordinates <- function(x) {
  xy <- as.data.frame(st_coordinates(x))
  level_columns <- grep("^L[0-9]+$", names(xy), value = TRUE)
  xy$group <- interaction(xy[, level_columns, drop = FALSE], drop = TRUE)
  xy
}

polygon_coordinates <- function(x) {
  xy <- as.data.frame(st_coordinates(x))
  level_columns <- grep("^L[0-9]+$", names(xy), value = TRUE)
  xy$group <- interaction(xy[, level_columns, drop = FALSE], drop = TRUE)
  xy
}

water_xy <- polygon_coordinates(water)
local_xy <- line_coordinates(local_roads)
major_xy <- line_coordinates(major_roads)
linear_water_xy <- line_coordinates(linear_water)

p <- ggplot() +
  geom_polygon(data = water_xy, aes(X, Y, group = group),
               fill = "#DDEFF4", colour = "#B8D7E1", linewidth = 0.18) +
  geom_path(data = local_xy, aes(X, Y, group = group),
            colour = "#E2E4E5", linewidth = 0.18, lineend = "round") +
  geom_path(data = major_xy, aes(X, Y, group = group),
            colour = "#BCC3C8", linewidth = 0.50, lineend = "round") +
  geom_path(data = linear_water_xy, aes(X, Y, group = group),
            colour = "#AFD3DF", linewidth = 0.48, lineend = "round") +
  geom_point(
    data = point_data,
    aes(station_lon, station_lat, fill = map_group,
        colour = map_group, shape = map_group),
    size = 3.05, stroke = 0.58
  ) +
  annotate("text", x = -87.6350, y = 41.8880,
           label = "Downtown Chicago (The Loop)",
           hjust = 1, vjust = 0, size = 5.0, fontface = "bold",
           colour = "#3A2A1B") +
  annotate("text", x = -87.6045, y = 41.7850,
           label = "University of Chicago",
           hjust = 1, vjust = 1, size = 5.0, fontface = "bold",
           colour = "#4A1D59") +
  annotate("text", x = -87.557, y = 41.995,
           label = "Lake Michigan", angle = 90,
           size = 4.6, fontface = "italic", colour = "#5E8795") +
  annotate("segment", x = -87.706, xend = -87.706,
           y = 42.022, yend = 42.047,
           linewidth = 0.65, colour = "#30343B",
           arrow = arrow(length = grid::unit(0.12, "inches"), type = "closed")) +
  annotate("text", x = -87.706, y = 42.053, label = "N",
           size = 4.2, fontface = "bold", colour = "#30343B") +
  scale_fill_manual(values = fill_values, drop = FALSE) +
  scale_colour_manual(values = outline_values, drop = FALSE) +
  scale_shape_manual(values = shape_values, drop = FALSE) +
  coord_cartesian(xlim = c(west, east), ylim = c(south, north), expand = FALSE) +
  guides(
    fill = guide_legend(
      title = NULL, order = 1,
      override.aes = list(
        size = 4.4, stroke = 0.75,
        shape = unname(shape_values),
        fill = unname(fill_values),
        colour = unname(outline_values)
      )
    ),
    colour = "none", shape = "none"
  ) +
  theme_void(base_family = "sans") +
  theme(
    plot.background = element_rect(fill = "white", colour = NA),
    panel.background = element_rect(fill = "#FAFAF9", colour = NA),
    legend.position = c(0.965, 0.975),
    legend.justification = c(1, 1),
    legend.background = element_rect(fill = scales::alpha("white", 0.95),
                                     colour = "#AAB2B8", linewidth = 0.35),
    legend.margin = margin(9, 11, 9, 11),
    legend.text = element_text(size = 12.5, colour = "#30343B"),
    legend.key.height = grid::unit(0.55, "cm"),
    legend.key.width = grid::unit(0.55, "cm"),
    plot.margin = margin(2, 2, 2, 2)
  )

counts <- table(stations$map_group)
stopifnot(unname(counts["Above Benchmark"]) == 11L)
stopifnot(unname(counts["Below Benchmark"]) == 4L)
stopifnot(unname(counts["Not rejected"]) == 329L)

output_file <- file.path(bundle, "results", "divvy_slope_tiger2019_point_map.png")
ggsave(output_file, p, width = 11, height = 11, dpi = 330,
       bg = "white", device = ragg::agg_png)
message("Saved: ", output_file)
message("Counts: 11 above, 4 below, 329 not rejected.")
