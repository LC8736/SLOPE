# Chicago Divvy real-data example

This directory is the self-contained real-data companion to the manuscript's
main simulation code. It contains the model-ready data, the Proposed
heterogeneous-slope detection code, verified output tables, and diagnostic figures.

## 1. Real data and sample

The application studies whether the response of daily Divvy departures to
temperature is heterogeneous across Chicago bicycle-sharing stations.

- Period: 1 January--31 March 2019 (2019 Q1).
- Panel units: 344 stable Divvy stations.
- Time observations: 90 calendar days.
- Balanced-panel size: `N = 344`, `T = 90`, and `NT = 30,960`.
- Outcome: `log(1 + daily departures)`.
- Heterogeneous regressor: station-level daily mean temperature in degrees C.
- Common control: station-level daily precipitation in millimetres.
- Temperature is used directly.
- All three model variables are standardized once over the full 30,960-row
  sample, followed by station-specific time demeaning to remove fixed effects.

The trip records originate from Divvy's public historical system data:
<https://divvybikes.com/system-data>. Individual trips were aggregated by
start date and start station to obtain daily departures.

Weather comes from Daymet Version 4, distributed by the ORNL DAAC:
<https://daymet.ornl.gov/>. Daily mean temperature is
`(tmax + tmin) / 2`, and precipitation is Daymet daily total precipitation.
Each station is assigned to its nearest 1 km Daymet grid centre. The 344
stations occupy 103 grids, so stations in the same grid share the same weather
on a given date. These values are gridded estimates, not measurements made at
the bicycle stations.

Station coordinates are supplied in
`data/divvy2019_station_temperature_grid_mapping.csv`. They were drawn from a
2019 station inventory retained by the `ccebra/Divvy-Data` project.

The geographic context in the station map is rendered locally from the U.S.
Census Bureau's 2019 TIGER/Line Shapefiles for Cook County, Illinois. The
bundled layers contain roads, areal hydrography, and linear hydrography. The map is
displayed with an adjusted aspect ratio to match the square manuscript figure
and therefore should not be used to measure distances. Source: U.S. Census
Bureau, *2019 TIGER/Line Shapefiles*:
<https://www.census.gov/geographies/mapping-files/time-series/geo/tiger-line-file.2019.html>.

`data/divvy2019_q1_model_data.csv` is the actual model input, not the original
trip-level archive. Its six columns are:

| Column | Meaning |
|---|---|
| `station_id` | Divvy station identifier |
| `station_name` | Station name |
| `date` | Calendar date |
| `departures` | Number of trips starting at the station that day |
| `temp_it_c` | Mean temperature from the nearest Daymet grid, degrees C |
| `prcp_it_mm` | Daily total precipitation from the nearest Daymet grid, mm |

## 2. Detection method

The real-data code implements the manuscript's Proposed method (Algorithm 1):

1. estimate the common precipitation coefficient and each station's initial
   temperature slope;
2. calculate pairwise distances between initial slopes;
3. set the neighborhood radius to the median pairwise distance
   (`tau_c = 0.50`), rank stations by their neighborhood proportions, and use
   the leading 60% (`k_c = 0.60`) as the preliminary common group;
4. estimate the common temperature slope from that group;
5. construct station-level LM statistics and chi-square p-values;
6. apply the Benjamini--Hochberg rule at `alpha = 0.05`.


The simulation implementation allows multivariate heterogeneous regressors.
This application is its one-regressor (`K = 1`) specialization.

## 3. Main results

| Quantity | Verified result |
|---|---:|
| Preliminary common group | 206 stations |
| Common standardized slope | 0.43922994 |
| Common original-scale slope | 0.06362339 log points per 1 degree C |
| Implied common demand change | 6.5691% per 1 degree C warmer |
| BH/FDR threshold | 0.00218023 |
| Detected stations | 15 |
| Above the common slope | 11 |
| Below the common slope | 4 |
| Not rejected | 329 |

The 11 Above Benchmark stations have stronger positive temperature slopes: in
the cold first quarter, their departures recover more strongly as temperature
rises. The four Below Benchmark stations have substantially smaller positive
slopes and are less responsive to warming. These are heterogeneous conditional
associations, not causal treatment effects.

| ID | Station | Direction | Standardized initial slope | Log-demand slope per 1 degree C |
|---:|---|---|---:|---:|
| 76 | Lake Shore Dr & Monroe St | Above | 0.901568 | 0.130594 |
| 268 | Lake Shore Dr & North Blvd | Above | 0.732737 | 0.106139 |
| 35 | Streeter Dr & Grand Ave | Above | 0.731599 | 0.105974 |
| 177 | Theater on the Lake | Above | 0.728678 | 0.105551 |
| 313 | Lakeview Ave & Fullerton Pkwy | Above | 0.727596 | 0.105394 |
| 85 | Michigan Ave & Oak St | Above | 0.700153 | 0.101419 |
| 6 | Dusable Harbor | Above | 0.664799 | 0.096298 |
| 3 | Shedd Aquarium | Above | 0.662421 | 0.095953 |
| 157 | Lake Shore Dr & Wellington Ave | Above | 0.654890 | 0.094862 |
| 145 | Mies van der Rohe Way & Chestnut St | Above | 0.654735 | 0.094840 |
| 331 | Halsted St & Clybourn Ave | Above | 0.643831 | 0.093260 |
| 425 | Harper Ave & 59th St | Below | 0.220863 | 0.031993 |
| 345 | Lake Park Ave & 56th St | Below | 0.214635 | 0.031090 |
| 426 | Ellis Ave & 60th St | Below | 0.195866 | 0.028372 |
| 252 | Greenwood Ave & 47th St | Below | 0.195602 | 0.028333 |

## 4. Directory structure

```text
chicago_real_data_code/
├── README.md
├── code/
│   ├── run_divvy2019_q1_model.R
│   └── plot_divvy_slope_tiger2019_map.R
├── data/
│   ├── divvy2019_q1_model_data.csv
│   ├── divvy2019_station_temperature_grid_mapping.csv
│   └── tiger2019/
│       ├── tl_2019_17031_roads/
│       ├── tl_2019_17031_areawater/
│       └── tl_2019_17031_linearwater/
└── results/
    ├── model_summary.csv
    ├── standardization_parameters.csv
    ├── station_results.csv
    ├── detected_anomalies.csv
    ├── direct_temperature_slope_distribution.png
    ├── direct_temperature_anomaly_map.png
    ├── divvy_slope_tiger2019_point_map.png
    └── sessionInfo.txt
```

## 5. Run the application

Required R packages:

```r
data.table
sf
ggplot2
ragg
scales
```

From the directory containing this README, run:

```bash
Rscript code/run_divvy2019_q1_model.R
```

By default, newly reproduced files are written to `reproduced_results/`, so the
verified files in `results/` are preserved. To deliberately rebuild the
verified results directory, use:

```bash
DIVVY_RESULTS_DIR=results Rscript code/run_divvy2019_q1_model.R
```

To reproduce the station map from the bundled Census TIGER/Line vectors and
the verified station-level results, run:

```bash
Rscript code/plot_divvy_slope_tiger2019_map.R
```

This writes `results/divvy_slope_tiger2019_point_map.png`. The map itself does
not contain an embedded source label; the TIGER/Line source is documented in
Section 1 and should be acknowledged in the manuscript figure note.

## 6. Result-table audit

The supplied tables were regenerated from the bundled model input and checked
against one another.

| File | Expected dimensions | Checks completed |
|---|---:|---|
| `model_summary.csv` | 1 row | N, T, tuning parameters, common slope, FDR threshold and counts reconciled |
| `standardization_parameters.csv` | 3 rows | Means and sample standard deviations recomputed from all 30,960 observations |
| `station_results.csv` | 344 rows | Unique station IDs, no missing values, coefficient conversions and rejection decisions verified |
| `detected_anomalies.csv` | 15 rows | Exactly equals the rejected subset of `station_results.csv`; 11 above and 4 below |

No required result table was missing. One misleading field name in the staging
files was corrected: `annual_departures` was the sum over January--March only.
It is now named `q1_total_departures`. The values themselves were correct.

Additional integrity checks passed:

- the input is a complete 344 by 90 balanced panel with no duplicate
  station-date rows and no missing values;
- all 344 station coordinates match the supplied station-grid mapping exactly;
- the stations occupy 103 Daymet grids, and weather is identical within each
  grid-day as required;
- the preliminary group contains 206 stations;
- all 15 rejected p-values are at or below the FDR threshold and all 329
  non-rejected p-values are above it;
- standardized-to-original coefficient conversions and percentage-effect
  calculations reconcile to numerical precision.
